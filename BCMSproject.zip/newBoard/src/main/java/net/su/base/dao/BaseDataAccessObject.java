package net.su.base.dao;



import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;


@Repository
public class BaseDataAccessObject extends SqlSessionDaoSupport{
	
}
