package net.su.base.service;

public interface BaseService {

}
