package net.su.login.vo;

public class CompanyValueObject {
 
	int company_seq;
	String company_name;
	int depart_seq;
	String depart_name;
	
	
	
	public int getDepart_seq() {
		return depart_seq;
	}
	public void setDepart_seq(int depart_seq) {
		this.depart_seq = depart_seq;
	}
	public String getDepart_name() {
		return depart_name;
	}
	public void setDepart_name(String depart_name) {
		this.depart_name = depart_name;
	}
	public int getCompany_seq() {
		return company_seq;
	}
	public void setCompany_seq(int company_seq) {
		this.company_seq = company_seq;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	
	
	

	
	
	

	
}
