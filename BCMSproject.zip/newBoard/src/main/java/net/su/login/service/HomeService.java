package net.su.login.service;

public interface HomeService {

}
