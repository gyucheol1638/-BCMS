package net.su.login.vo;

public class HomeValueObject {
	private String seq;
	private String data;
	
	public String getSeq(){
		return seq;
	}
	
	public void setSeq(String seq){
		this.seq = seq;
	}
	
	public String getData(){
		return data;
	}
	
	public void setData(String data){
		this.data = data;
	}
	

}
